﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Bitszer;

public sealed class GameManager : MonoBehaviour
{
    [Header("Components")]
    [SerializeField] private Text _healthPotionsText = null;
    
    /*
     * Mono Behavior.
     */
    
    private void Awake()
    {
        InitializeAuctionHouse();
    }
    
    /*
     * Auction House.
     */
    
    public void OpenAuctionHouse()
    {
        AuctionHouse.Open();
    }

    private void InitializeAuctionHouse()
    {
        Debug.Log("Auction House: initializing...");
        
        AuctionHouse.Initialize("us-west-2:097482bc-b5ae-4ec3-8db3-c39d98f393bb");     
        AuctionHouse.OnInitialized += OnAuctionHouseInitialized;
        AuctionHouse.OnItemsChanged += OnAuctionHouseItemsChanged;
    }

    private void SaveToAuctionHouse(int healthPotionsAmount)
    {
        var dict = new Dictionary<string, int>();
        dict.Add("health_potions", healthPotionsAmount);
        AuctionHouse.SetItems(dict, true);
    }
    
    private void OnAuctionHouseInitialized()
    {
        Debug.Log("Auction House: initialized");

        var dict = AuctionHouse.GetItems();
        var healthPotions = dict["health_potions"];

        _healthPotionsText.text = healthPotions.ToString(); 
    }
    
    private void OnAuctionHouseItemsChanged(Dictionary<string, int> itemsDeltas)
    {
        Debug.Log("Auction House: items changed");
        
        var dict = AuctionHouse.GetItems();
        var healthPotions = dict["health_potions"];
        var healthPotionsDelta = itemsDeltas["health_potions"];
        var healthPotionsDeltaString = healthPotionsDelta > 0 ? $"+{healthPotionsDelta}" : healthPotionsDelta.ToString(); 
        
        _healthPotionsText.text = $"{healthPotions} ({healthPotionsDeltaString})";
    }

    /*
     * Health Potions.
     */
    
    public void AddRandomHealthPotions()
    {
        var amountCurrent = int.Parse(_healthPotionsText.text);
        var amountToAdd = new System.Random().Next(1, 10);
        var amountNew = amountCurrent + amountToAdd;

        _healthPotionsText.text = amountNew.ToString();
        SaveToAuctionHouse(amountNew);
    }
}